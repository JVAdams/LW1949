library(testthat)
library(magrittr)
library(LW1949)

test_check("LW1949")