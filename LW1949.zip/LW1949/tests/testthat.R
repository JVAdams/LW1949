library(testthat)
library(LW1949)

test_check("LW1949")