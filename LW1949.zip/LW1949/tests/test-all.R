library(testthat)
library(LW1949)

test_package("LW1949")